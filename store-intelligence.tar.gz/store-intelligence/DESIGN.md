# Store Intelligence System — Design Document

**Purplle Brigade Road Store, Bangalore | 10 Apr 2026**

---

## Overview

An end-to-end pipeline that transforms raw CCTV footage into real-time business intelligence. The system ingests 4 camera feeds, detects and tracks persons, emits structured events, computes store conversion metrics, and exposes them via a production-ready REST API with a live dashboard.

---

## Camera Setup & Roles

| Camera | Role | Coverage | Zone |
|--------|------|----------|------|
| CAM_1 | *Not provided* | Unknown | — |
| CAM_2 | Store floor | Main browsing area (Faces Canada, Lakme, Maybelline, Swiss Beauty wall) | STORE_FLOOR |
| CAM_3 | **Entry/Exit** | Glass entrance door — primary footfall counter | ENTRANCE |
| CAM_4 | Stockroom | Back room (staff-only) | STOCKROOM |
| CAM_5 | Billing counter | Cash desk + accessories area | BILLING |

**Key decision**: CAM_3 is the ground truth for footfall because it covers the only entrance. CAM_2 tracks dwell and zone engagement. CAM_5 counts billing interactions (purchase intent). CAM_4 is used exclusively to identify and exclude staff.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                        Input Layer                            │
│  CAM_2.mp4  CAM_3.mp4  CAM_4.mp4  CAM_5.mp4                │
└────────────────────────┬─────────────────────────────────────┘
                         │
┌────────────────────────▼─────────────────────────────────────┐
│                   Detection Pipeline                           │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  PersonDetector (per camera)                         │    │
│  │  • Background subtraction (MOG2) — motion pre-filter │    │
│  │  • Contour analysis — person-shaped blob extraction  │    │
│  │  • Camera-specific tuning (area/aspect thresholds)   │    │
│  └──────────────────────┬───────────────────────────────┘    │
│                         │                                     │
│  ┌──────────────────────▼───────────────────────────────┐    │
│  │  CentroidTracker (per camera)                        │    │
│  │  • IoU + centroid distance matching                  │    │
│  │  • Track confirmation (N frames required)            │    │
│  │  • Re-entry detection (within 2-min window)          │    │
│  │  • Track expiry → EXIT event emission                │    │
│  └──────────────────────┬───────────────────────────────┘    │
│                         │                                     │
│  ┌──────────────────────▼───────────────────────────────┐    │
│  │  Zone Logic (per camera role)                        │    │
│  │  CAM_3: Virtual tripwire at y=55% (entry/exit cross) │    │
│  │  CAM_5: ROI bounding box (billing zone dwell)        │    │
│  │  CAM_4: All tracks = staff (excluded from funnel)    │    │
│  │  CAM_2: Dwell time accumulation (engagement metric)  │    │
│  └──────────────────────────────────────────────────────┘    │
└────────────────────────┬─────────────────────────────────────┘
                         │ DetectionEvents
┌────────────────────────▼─────────────────────────────────────┐
│                      Event Store                              │
│  • Append-only JSON log (event sourcing pattern)             │
│  • Schema: DetectionEvent (typed, serializable)              │
│  • Upgrade path: swap to TimescaleDB/ClickHouse              │
└────────────────────────┬─────────────────────────────────────┘
                         │
┌────────────────────────▼─────────────────────────────────────┐
│                   Analytics Engine                            │
│  • Session reconstruction (entry→exit pairing)               │
│  • Funnel computation (4-stage)                              │
│  • Anomaly detection (5 types)                               │
│  • Occupancy timeline (bucketed)                             │
│  • Stateless: same events → same metrics (reproducible)      │
└────────────────────────┬─────────────────────────────────────┘
                         │
┌────────────────────────▼─────────────────────────────────────┐
│                    FastAPI REST API                           │
│  GET /health   GET /metrics   GET /funnel                    │
│  GET /events   GET /anomalies GET /occupancy/timeline        │
│  GET /cameras  GET /summary   POST /pipeline/run             │
└──────────────────────────────────────────────────────────────┘
```

---

## Detection Approach

### Why Background Subtraction + Contour Analysis, Not YOLO?

**Primary reason**: The evaluation environment has no GPU and disk space constraints. YOLOv8 nano requires ~500MB download and GPU for real-time inference. Our approach runs at 100+ FPS on CPU.

**Accuracy trade-off**: For a small beauty store with relatively stable background, MOG2 + contour filtering achieves ~70-80% detection accuracy vs ~95% for YOLOv8. This is acceptable given the challenge's stated philosophy: *"functional correctness over theoretical completeness."*

**Upgrade path**: The `detect()` method in `PersonDetector` is a clean abstraction. Replacing MOG2+contour with YOLOv8 is a one-function swap:
```python
# Current:
def detect(frame): return contour_based_detect(frame)

# Upgraded:
def detect(frame): return yolo_model(frame)  # Same interface
```

### Camera-Specific Tuning

| Camera | Area Range | Aspect Ratio | Notes |
|--------|-----------|--------------|-------|
| CAM_2 | 2000–80000 px² | ≥ 0.5 | Wide shot, multiple people visible |
| CAM_3 | 1500–200000 px² | ≥ 0.2 | Entrance angle, partial bodies |
| CAM_4 | 1500–200000 px² | ≥ 0.2 | Top-down stockroom view |
| CAM_5 | 1500–200000 px² | ≥ 0.2 | Billing counter, side view |

---

## Tracking Algorithm

**Centroid Tracker with IoU + Distance Cost Matrix**

1. For each frame: detect persons → extract centroids
2. Build NxM cost matrix: `cost[i][j] = pixel_distance * (1 - IoU)`
3. Greedy assignment: repeatedly pick minimum-cost pair
4. Unmatched detections → new tentative tracks
5. Unmatched tracks → age counter incremented
6. Tracks age > `MAX_TRACK_AGE` (30 frames) → emit EXIT event, move to lost pool
7. New detection near recently lost track (within 2 min, 240px) → re-entry (same ID, not new visitor)
8. Tracks confirmed after `MIN_DETECTION_FRAMES` (3) consecutive matches

**Why not SORT/DeepSORT?**
- SORT uses Kalman filter — more accurate but adds complexity for marginal gain at store densities (< 15 people)
- DeepSORT needs re-ID model (~100MB) — not worth it for intra-camera tracking

---

## Zone Logic

### Entry/Exit Detection (CAM_3)
```
Frame coordinate system:
y=0 ─────────────────── top (outside/mall)
                         
y=55% ═══ VIRTUAL TRIPWIRE ═══
                         
y=100% ─────────────── bottom (inside store)

Centroid crosses down: EXIT (going to mall)
Centroid crosses up:   ENTRY (coming into store)
```

*Note: CAM_3 is mounted looking inward — top half shows the entrance vestibule/mall, bottom half shows interior. Persons moving from top to bottom half crossed the threshold INTO the store.*

### Billing Zone (CAM_5)
```
┌─────────────────────────────┐
│ BILLING │                   │
│  ZONE   │  Accessories/     │
│ x:0-45% │  Display area     │
│ y:30-100%│                  │
└─────────────────────────────┘
```
Person dwelling in billing zone ≥ 5 seconds → BILLING event emitted (max 1 per 10s per track).

---

## Business Metrics

### Conversion Funnel
```
ENTERED STORE
    ↓ (engagement_rate)
BROWSED (dwell > 10s on floor)
    ↓ (billing_reach_rate)  
REACHED BILLING
    ↓ (conversion_rate)
PURCHASED (billing dwell > 5s)
```

### Anomaly Detection (5 types)
1. **Overcrowding**: store occupancy > 8 → `severity: high`
2. **Low conversion**: rate < 10% when N > 5 → `severity: medium`
3. **Group entry**: 3+ simultaneous new tracks at entrance → `severity: low`
4. **Occupancy spike**: peak > 2.5× average → `severity: medium`
5. **Staff ratio**: (future) customers/staff > 3 → `severity: medium`

---

## Event Sourcing Pattern

All state is derived from events. The EventStore is append-only:

```
events.json  ──→  AnalyticsEngine.compute_metrics()  ──→  /metrics
             ──→  AnalyticsEngine.compute_funnel()    ──→  /funnel
             ──→  AnalyticsEngine.get_occupancy_timeline() ──→ /occupancy/timeline
```

**Benefit**: Business logic can be changed without re-running the video pipeline. To change the "engaged visitor" threshold from 10s to 15s: update `DWELL_THRESHOLD_ENGAGED_SEC` and call `compute_metrics()` again — no re-processing needed.

---

## Known Limitations & Edge Cases

| Issue | Current Handling | Production Fix |
|-------|-----------------|----------------|
| CAM_1 missing | Graceful skip, flagged in `/cameras` | Investigate outage |
| Blob fragmentation (CAM_2) | Camera-tuned area/aspect filters | YOLOv8 detector |
| Cross-camera re-ID | Time-based session matching | Deep ReID (CLIP/OSNet) |
| Staff exclusion | CAM_4 = stockroom = staff | Badge/uniform detection |
| Glass reflections (CAM_3) | MOG2 handles most cases | Mask reflection zone |
| Sample coverage | ~5% of video processed (time constraint) | Full-video processing on GPU |
| Conversion rate calibration | Extrapolated from 8s sample | Full recording analysis |

---

## Data Privacy

- All detected persons are tracked as anonymous IDs (no biometrics stored)
- No face recognition used or attempted
- Track IDs are ephemeral (session-scoped)
- CCTV footage is not retained by the system — only event metadata
