"""
Store Intelligence System — Configuration
Purplle Brigade Road Store, Bangalore
Recording date: 10/04/2026
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

# ─── Camera Roles ──────────────────────────────────────────────────────────────
CAMERA_ROLES = {
    "CAM_2": "store_floor",      # Main browsing area — tracks dwell & engagement
    "CAM_3": "entrance_exit",    # Glass door — primary entry/exit counter
    "CAM_4": "stockroom",        # Back room — staff-only zone (exclusion zone)
    "CAM_5": "billing_counter",  # Cash counter — tracks purchase intent & conversion
}

# CAM_1 was not provided; system handles gracefully with 4-camera setup
AVAILABLE_CAMERAS = ["CAM_2", "CAM_3", "CAM_4", "CAM_5"]
ENTRY_EXIT_CAMERA = "CAM_3"
BILLING_CAMERA = "CAM_5"
FLOOR_CAMERA = "CAM_2"
STOCKROOM_CAMERA = "CAM_4"

# ─── Detection Zones (normalized 0-1 relative to frame dimensions) ─────────────
# CAM_3 (entrance): entry = bottom half of frame (inside store), exit = top half crossing to outside
ENTRY_LINE_CAM3 = {
    "line_y": 0.55,   # Horizontal line — crossing bottom-to-top = exit, top-to-bottom = entry
    "direction": "vertical_cross",
}

# CAM_5 (billing): billing zone is left portion where counter is
BILLING_ZONE_CAM5 = {
    "x1": 0.0, "y1": 0.3,
    "x2": 0.45, "y2": 1.0,
}

# Stockroom zone for staff filtering (CAM_4 almost entirely staff)
STOCKROOM_ZONE = {
    "x1": 0.0, "y1": 0.0,
    "x2": 1.0, "y2": 1.0,
}

# ─── Tracking Parameters ───────────────────────────────────────────────────────
DETECTION_CONFIDENCE = 0.4          # YOLO person detection threshold
IOU_THRESHOLD = 0.3                 # Intersection over union for NMS
MAX_TRACK_AGE = 30                  # Frames before a lost track is removed
MAX_TRACK_DISTANCE = 120            # Max pixel distance for re-association
RE_ENTRY_WINDOW_SECONDS = 120       # Time window to consider as re-entry (not new visitor)
MIN_DETECTION_FRAMES = 3            # Minimum frames to confirm a person (reduces false positives)

# ─── Business Logic Parameters ─────────────────────────────────────────────────
STAFF_EXCLUSION_CAM = "CAM_4"       # Tracks in stockroom = staff
STAFF_DWELL_THRESHOLD_SEC = 30      # Person in stockroom >30s = staff
DWELL_THRESHOLD_ENGAGED_SEC = 10    # >10s in store = engaged visitor
BILLING_DWELL_THRESHOLD_SEC = 5     # >5s at billing = purchase intent

# Session / funnel
SESSION_TIMEOUT_SEC = 300           # 5 min inactivity = session end

# ─── Anomaly Detection ─────────────────────────────────────────────────────────
OVERCROWDING_THRESHOLD = 8          # >8 people in store simultaneously = alert
LOW_CONVERSION_THRESHOLD = 0.10     # <10% conversion rate = anomaly
STAFF_CUSTOMER_RATIO_ALERT = 3.0    # >3 customers per staff member = understaffed alert
PEAK_HOUR_THRESHOLD = 5             # >5 entries in 5-minute window = peak

# ─── Video Processing ──────────────────────────────────────────────────────────
PROCESS_EVERY_N_FRAMES = 3          # Process every 3rd frame (efficiency vs accuracy trade-off)
                                    # At 25-30fps → ~10fps effective detection rate
OUTPUT_VIDEO = False                # Set True to write annotated video

# ─── Storage ───────────────────────────────────────────────────────────────────
EVENTS_DB_PATH = "data/events.json"
METRICS_CACHE_TTL = 5               # Seconds before recomputing metrics

# ─── API ───────────────────────────────────────────────────────────────────────
API_HOST = "0.0.0.0"
API_PORT = 8000
API_VERSION = "v1"
