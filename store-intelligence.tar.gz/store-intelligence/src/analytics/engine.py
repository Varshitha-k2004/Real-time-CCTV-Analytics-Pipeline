"""
Analytics Engine

Computes business metrics from raw events.
All metrics are derived; events are the source of truth.

Metrics computed:
- Total footfall (entries, unique visitors)
- Conversion rate (billing dwellers / total entries)
- Average dwell time
- Funnel: Entered → Browsed → Billing → Purchased
- Peak hours / occupancy timeline
- Anomalies
- Per-zone heatmap data
- Staff vs customer ratio
"""

import time
import uuid
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from dataclasses import dataclass, asdict

from src.events.schema import DetectionEvent, EventType, Session, EventStore, Zone
from config.settings import (
    DWELL_THRESHOLD_ENGAGED_SEC,
    BILLING_DWELL_THRESHOLD_SEC,
    SESSION_TIMEOUT_SEC,
    LOW_CONVERSION_THRESHOLD,
    OVERCROWDING_THRESHOLD,
    STAFF_CUSTOMER_RATIO_ALERT,
)


@dataclass
class FunnelMetrics:
    total_entries: int
    engaged_visitors: int          # Stayed > DWELL_THRESHOLD
    reached_billing: int           # Seen at billing counter
    estimated_purchases: int       # Billing dwell > threshold
    conversion_rate: float         # purchases / entries
    engagement_rate: float         # engaged / entries
    billing_reach_rate: float      # billing / entries


@dataclass
class DwellMetrics:
    avg_dwell_seconds: float
    median_dwell_seconds: float
    max_dwell_seconds: float
    distribution: Dict[str, int]   # "0-30s", "30-60s", "1-5m", "5m+" buckets


@dataclass
class OccupancySnapshot:
    timestamp: float
    occupancy: int
    camera_id: str


@dataclass
class Anomaly:
    anomaly_id: str
    anomaly_type: str
    severity: str                  # "low", "medium", "high"
    timestamp: float
    description: str
    value: float
    threshold: float
    metadata: dict


@dataclass
class StoreMetrics:
    """Complete metrics snapshot — returned by /metrics API endpoint."""
    computed_at: float
    recording_duration_seconds: float
    recording_date: str

    # Footfall
    total_entries: int
    total_exits: int
    unique_visitors: int
    staff_count: int
    net_in_store: int              # entries - exits (current occupancy estimate)

    # Funnel
    funnel: FunnelMetrics

    # Dwell
    dwell: DwellMetrics

    # Peak
    peak_occupancy: int
    peak_time: Optional[float]
    avg_occupancy: float

    # Zone breakdown
    zone_breakdown: Dict[str, int]

    # Anomalies
    anomalies: List[Anomaly]

    # Raw event count
    total_events: int

    def to_dict(self) -> dict:
        d = {
            "computed_at": self.computed_at,
            "recording_duration_seconds": self.recording_duration_seconds,
            "recording_date": self.recording_date,
            "total_entries": self.total_entries,
            "total_exits": self.total_exits,
            "unique_visitors": self.unique_visitors,
            "staff_count": self.staff_count,
            "net_in_store": self.net_in_store,
            "funnel": asdict(self.funnel),
            "dwell": {
                "avg_dwell_seconds": self.dwell.avg_dwell_seconds,
                "median_dwell_seconds": self.dwell.median_dwell_seconds,
                "max_dwell_seconds": self.dwell.max_dwell_seconds,
                "distribution": self.dwell.distribution,
            },
            "peak_occupancy": self.peak_occupancy,
            "peak_time": self.peak_time,
            "avg_occupancy": self.avg_occupancy,
            "zone_breakdown": self.zone_breakdown,
            "anomalies": [asdict(a) for a in self.anomalies],
            "total_events": self.total_events,
        }
        return d


class AnalyticsEngine:
    """
    Derives all business metrics from the event store.

    Design: stateless computation — given the same events, always returns
    the same metrics. Safe to call multiple times.
    """

    def __init__(self, event_store: EventStore):
        self.store = event_store

    def _build_sessions(self) -> List[Session]:
        """
        Build visitor sessions from ENTRY/EXIT/BILLING events.
        A session = one continuous visit (entry → exit pair).
        """
        sessions: Dict[str, Session] = {}
        completed: List[Session] = []

        events = sorted(self.store.all(), key=lambda e: e.timestamp)

        for ev in events:
            if ev.is_staff:
                continue

            if ev.event_type == EventType.ENTRY:
                pid = ev.track_id
                sess = Session(
                    session_id=str(uuid.uuid4()),
                    global_person_id=pid,
                    entry_time=ev.timestamp,
                )
                sessions[pid] = sess

            elif ev.event_type == EventType.EXIT:
                pid = ev.track_id
                if pid in sessions:
                    sess = sessions.pop(pid)
                    sess.exit_time = ev.timestamp
                    if ev.dwell_seconds:
                        sess.dwell_seconds = ev.dwell_seconds
                    elif sess.exit_time and sess.entry_time:
                        sess.dwell_seconds = sess.exit_time - sess.entry_time
                    completed.append(sess)

            elif ev.event_type == EventType.DWELL:
                pid = ev.track_id
                if pid in sessions:
                    sess = sessions[pid]
                    sess.reached_floor = True
                    if ev.dwell_seconds and ev.dwell_seconds > sess.dwell_seconds:
                        sess.dwell_seconds = ev.dwell_seconds

            elif ev.event_type == EventType.BILLING:
                pid = ev.track_id
                # Billing events come from CAM_5 which has different track IDs
                # Match to open session by time proximity
                matching = self._find_closest_session(sessions, ev.timestamp)
                if matching:
                    matching.reached_billing = True
                    if ev.dwell_seconds and ev.dwell_seconds >= BILLING_DWELL_THRESHOLD_SEC:
                        matching.purchased = True

        # Sessions without exit = still in store at end of recording
        for sess in sessions.values():
            completed.append(sess)

        return completed

    def _find_closest_session(
        self, sessions: Dict[str, Session], timestamp: float
    ) -> Optional[Session]:
        """Find open session closest in time to a billing event."""
        best = None
        best_diff = float("inf")
        for sess in sessions.values():
            diff = abs(timestamp - sess.entry_time)
            if diff < best_diff:
                best_diff = diff
                best = sess
        return best if best_diff < SESSION_TIMEOUT_SEC else None

    def compute_metrics(self) -> StoreMetrics:
        events = self.store.all()
        if not events:
            return self._empty_metrics()

        sorted_events = sorted(events, key=lambda e: e.timestamp)
        t_start = sorted_events[0].timestamp
        t_end = sorted_events[-1].timestamp
        duration = t_end - t_start

        # ── Footfall ──────────────────────────────────────────────────────────
        entry_events = [e for e in events if e.event_type == EventType.ENTRY and not e.is_staff]
        exit_events = [e for e in events if e.event_type == EventType.EXIT and not e.is_staff]
        staff_events = [e for e in events if e.event_type == EventType.STAFF_DETECTED]
        billing_events = [e for e in events if e.event_type == EventType.BILLING]

        total_entries = len(entry_events)
        total_exits = len(exit_events)

        # Unique visitors = unique track IDs in entry events
        unique_track_ids = set(e.track_id for e in entry_events)
        unique_visitors = len(unique_track_ids)
        staff_count = len(set(e.track_id for e in staff_events))

        net_in_store = max(0, total_entries - total_exits)

        # ── Funnel ────────────────────────────────────────────────────────────
        dwell_events = [e for e in events if e.event_type == EventType.DWELL and not e.is_staff]
        engaged_tracks = set(e.track_id for e in dwell_events
                             if e.dwell_seconds and e.dwell_seconds >= DWELL_THRESHOLD_ENGAGED_SEC)

        billing_tracks = set(e.track_id for e in billing_events)
        billing_dwell_events = [e for e in billing_events
                                if e.dwell_seconds and e.dwell_seconds >= BILLING_DWELL_THRESHOLD_SEC]
        purchases = len(billing_dwell_events)

        # Also count from sessions
        sessions = self._build_sessions()
        customer_sessions = [s for s in sessions if not s.is_staff]

        # Supplement funnel from sessions
        if not total_entries and customer_sessions:
            total_entries = len(customer_sessions)
            unique_visitors = len(set(s.global_person_id for s in customer_sessions))

        engaged_count = len(engaged_tracks) or sum(1 for s in customer_sessions if s.reached_floor)
        billing_reach = len(billing_tracks) or sum(1 for s in customer_sessions if s.reached_billing)
        purchases = purchases or sum(1 for s in customer_sessions if s.purchased)

        conversion_rate = purchases / total_entries if total_entries > 0 else 0.0
        engagement_rate = engaged_count / total_entries if total_entries > 0 else 0.0
        billing_reach_rate = billing_reach / total_entries if total_entries > 0 else 0.0

        funnel = FunnelMetrics(
            total_entries=total_entries,
            engaged_visitors=engaged_count,
            reached_billing=billing_reach,
            estimated_purchases=purchases,
            conversion_rate=round(conversion_rate, 4),
            engagement_rate=round(engagement_rate, 4),
            billing_reach_rate=round(billing_reach_rate, 4),
        )

        # ── Dwell Time ────────────────────────────────────────────────────────
        dwell_times = []
        for e in dwell_events:
            if e.dwell_seconds and e.dwell_seconds > 0:
                dwell_times.append(e.dwell_seconds)
        for s in customer_sessions:
            if s.dwell_seconds > 0:
                dwell_times.append(s.dwell_seconds)

        if dwell_times:
            import statistics
            dwell_times_sorted = sorted(dwell_times)
            avg_dwell = statistics.mean(dwell_times)
            med_dwell = statistics.median(dwell_times)
            max_dwell = max(dwell_times)
        else:
            avg_dwell = med_dwell = max_dwell = 0.0

        dist = {"0-30s": 0, "30-120s": 0, "2-5min": 0, "5min+": 0}
        for d in dwell_times:
            if d < 30:
                dist["0-30s"] += 1
            elif d < 120:
                dist["30-120s"] += 1
            elif d < 300:
                dist["2-5min"] += 1
            else:
                dist["5min+"] += 1

        dwell_metrics = DwellMetrics(
            avg_dwell_seconds=round(avg_dwell, 1),
            median_dwell_seconds=round(med_dwell, 1),
            max_dwell_seconds=round(max_dwell, 1),
            distribution=dist,
        )

        # ── Occupancy Timeline ────────────────────────────────────────────────
        occupancy_snapshots = [e.store_occupancy for e in events
                               if e.store_occupancy is not None]
        peak_occupancy = max(occupancy_snapshots) if occupancy_snapshots else 0
        avg_occupancy = (sum(occupancy_snapshots) / len(occupancy_snapshots)
                         if occupancy_snapshots else 0.0)

        # Find peak time
        peak_ev = None
        for e in sorted_events:
            if e.store_occupancy == peak_occupancy:
                peak_ev = e
                break
        peak_time = peak_ev.timestamp if peak_ev else None

        # ── Zone Breakdown ────────────────────────────────────────────────────
        zone_breakdown = defaultdict(int)
        for e in events:
            zone_breakdown[e.zone.value] += 1

        # ── Anomalies ─────────────────────────────────────────────────────────
        anomalies = self._detect_anomalies(events, funnel, peak_occupancy, avg_occupancy)

        return StoreMetrics(
            computed_at=time.time(),
            recording_duration_seconds=round(duration, 1),
            recording_date="10 Apr 2026",
            total_entries=total_entries,
            total_exits=total_exits,
            unique_visitors=unique_visitors,
            staff_count=staff_count,
            net_in_store=net_in_store,
            funnel=funnel,
            dwell=dwell_metrics,
            peak_occupancy=peak_occupancy,
            peak_time=peak_time,
            avg_occupancy=round(avg_occupancy, 1),
            zone_breakdown=dict(zone_breakdown),
            anomalies=anomalies,
            total_events=len(events),
        )

    def compute_funnel(self) -> dict:
        metrics = self.compute_metrics()
        f = metrics.funnel
        return {
            "stages": [
                {
                    "stage": "Entered Store",
                    "count": f.total_entries,
                    "rate": 1.0,
                    "drop_off": 0,
                },
                {
                    "stage": "Browsed (Engaged)",
                    "count": f.engaged_visitors,
                    "rate": round(f.engagement_rate, 4),
                    "drop_off": f.total_entries - f.engaged_visitors,
                },
                {
                    "stage": "Reached Billing",
                    "count": f.reached_billing,
                    "rate": round(f.billing_reach_rate, 4),
                    "drop_off": f.engaged_visitors - f.reached_billing,
                },
                {
                    "stage": "Purchased",
                    "count": f.estimated_purchases,
                    "rate": round(f.conversion_rate, 4),
                    "drop_off": f.reached_billing - f.estimated_purchases,
                },
            ],
            "conversion_rate": f.conversion_rate,
            "key_insight": self._funnel_insight(f),
        }

    def _funnel_insight(self, f: FunnelMetrics) -> str:
        if f.total_entries == 0:
            return "No visitor data available."
        if f.engagement_rate < 0.5:
            return "Low engagement: most visitors left without browsing. Consider entrance display improvements."
        if f.billing_reach_rate < 0.3:
            return "Visitors browse but few reach billing. Checkout friction or staff availability may be an issue."
        if f.conversion_rate < LOW_CONVERSION_THRESHOLD:
            return "Low conversion despite billing visits. Product-price mismatch or long wait times suspected."
        return f"Healthy conversion at {f.conversion_rate:.0%}. Store performing well during this window."

    def _detect_anomalies(
        self, events, funnel: FunnelMetrics, peak_occ: int, avg_occ: float
    ) -> List[Anomaly]:
        anomalies = []
        t = time.time()

        # 1. Overcrowding
        peak_alerts = [e for e in events if e.event_type == EventType.PEAK_ALERT]
        if peak_alerts:
            anomalies.append(Anomaly(
                anomaly_id=str(uuid.uuid4()),
                anomaly_type="overcrowding",
                severity="high",
                timestamp=peak_alerts[0].timestamp,
                description=f"Store occupancy exceeded {OVERCROWDING_THRESHOLD} persons",
                value=float(peak_occ),
                threshold=float(OVERCROWDING_THRESHOLD),
                metadata={"event_count": len(peak_alerts)},
            ))

        # 2. Low conversion
        if funnel.total_entries > 5 and funnel.conversion_rate < LOW_CONVERSION_THRESHOLD:
            anomalies.append(Anomaly(
                anomaly_id=str(uuid.uuid4()),
                anomaly_type="low_conversion",
                severity="medium",
                timestamp=t,
                description=f"Conversion rate {funnel.conversion_rate:.1%} below threshold {LOW_CONVERSION_THRESHOLD:.0%}",
                value=funnel.conversion_rate,
                threshold=LOW_CONVERSION_THRESHOLD,
                metadata={},
            ))

        # 3. Group entries
        group_events = [e for e in events if e.event_type == EventType.GROUP_ENTRY]
        if group_events:
            anomalies.append(Anomaly(
                anomaly_id=str(uuid.uuid4()),
                anomaly_type="group_entry",
                severity="low",
                timestamp=group_events[0].timestamp,
                description=f"{len(group_events)} group entry events detected",
                value=float(len(group_events)),
                threshold=1.0,
                metadata={"groups": [g.group_size for g in group_events]},
            ))

        # 4. Peak occupancy spike
        if peak_occ > avg_occ * 2.5 and avg_occ > 0:
            anomalies.append(Anomaly(
                anomaly_id=str(uuid.uuid4()),
                anomaly_type="occupancy_spike",
                severity="medium",
                timestamp=t,
                description=f"Peak occupancy ({peak_occ}) was {peak_occ/avg_occ:.1f}x average ({avg_occ:.1f})",
                value=float(peak_occ),
                threshold=float(avg_occ * 2.5),
                metadata={},
            ))

        return anomalies

    def get_occupancy_timeline(self, bucket_seconds: int = 30) -> List[dict]:
        """
        Aggregate occupancy by time bucket for dashboard timeline chart.
        """
        occ_events = [e for e in self.store.all() if e.store_occupancy is not None]
        if not occ_events:
            return []

        occ_events.sort(key=lambda e: e.timestamp)
        t_start = occ_events[0].timestamp
        timeline = defaultdict(list)

        for e in occ_events:
            bucket = int((e.timestamp - t_start) / bucket_seconds) * bucket_seconds
            timeline[bucket].append(e.store_occupancy)

        return [
            {"time_offset_seconds": k, "avg_occupancy": round(sum(v) / len(v), 1)}
            for k, v in sorted(timeline.items())
        ]

    def _empty_metrics(self) -> StoreMetrics:
        empty_funnel = FunnelMetrics(0, 0, 0, 0, 0.0, 0.0, 0.0)
        empty_dwell = DwellMetrics(0.0, 0.0, 0.0, {})
        return StoreMetrics(
            computed_at=time.time(),
            recording_duration_seconds=0,
            recording_date="10 Apr 2026",
            total_entries=0, total_exits=0, unique_visitors=0,
            staff_count=0, net_in_store=0,
            funnel=empty_funnel, dwell=empty_dwell,
            peak_occupancy=0, peak_time=None, avg_occupancy=0.0,
            zone_breakdown={}, anomalies=[], total_events=0,
        )
