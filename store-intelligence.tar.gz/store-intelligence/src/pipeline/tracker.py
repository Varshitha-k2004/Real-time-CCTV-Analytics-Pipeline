"""
Multi-Object Tracker — Centroid + IoU Based

Design decision: We use a lightweight centroid tracker with IoU matching
rather than a deep re-ID model. Reasons:
1. No GPU required — runs on CPU in production
2. Sufficient for single-camera tracking with stable overhead views
3. Cross-camera re-ID is handled separately at the session level

For production upgrade path: swap _match_detections() with a deep ReID
model (CLIP-based or OSNet) for more accurate cross-camera linking.

Handles:
- Re-entry within RE_ENTRY_WINDOW_SECONDS (same track ID, not new visitor)
- Brief occlusions (MAX_TRACK_AGE frames of no detection)
- Group entry (multiple simultaneous new tracks from entrance zone)
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np

from config.settings import (
    MAX_TRACK_AGE,
    MAX_TRACK_DISTANCE,
    RE_ENTRY_WINDOW_SECONDS,
    MIN_DETECTION_FRAMES,
)


@dataclass
class Track:
    track_id: str
    camera_id: str
    bbox: Tuple[float, float, float, float]   # x1, y1, x2, y2 (pixel coords)
    centroid: Tuple[float, float]
    first_seen_frame: int
    last_seen_frame: int
    first_seen_time: float
    last_seen_time: float
    confirmed: bool = False          # True after MIN_DETECTION_FRAMES
    age: int = 0                     # Frames since last detection
    hit_count: int = 1               # Number of frames this track was matched
    is_staff: bool = False
    global_id: Optional[str] = None  # Cross-camera resolved identity


class CentroidTracker:
    """
    Tracks persons across frames within a single camera.

    Algorithm:
    1. For each new frame's detections, compute IoU with existing tracks
    2. Use Hungarian-style greedy matching (IoU + centroid distance)
    3. Unmatched detections → new tracks (tentative)
    4. Tracks with age > MAX_TRACK_AGE → removed (emits EXIT event)
    5. New tracks confirmed after MIN_DETECTION_FRAMES hits
    """

    def __init__(self, camera_id: str):
        self.camera_id = camera_id
        self.active_tracks: Dict[str, Track] = {}
        self.lost_tracks: Dict[str, Track] = {}   # Recently lost — for re-entry detection
        self._next_id_counter = 0

    def _new_track_id(self) -> str:
        self._next_id_counter += 1
        return f"{self.camera_id}_T{self._next_id_counter:04d}"

    def _centroid(self, bbox: Tuple) -> Tuple[float, float]:
        x1, y1, x2, y2 = bbox
        return ((x1 + x2) / 2, (y1 + y2) / 2)

    def _iou(self, b1: Tuple, b2: Tuple) -> float:
        x1 = max(b1[0], b2[0])
        y1 = max(b1[1], b2[1])
        x2 = min(b1[2], b2[2])
        y2 = min(b1[3], b2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        a1 = (b1[2] - b1[0]) * (b1[3] - b1[1])
        a2 = (b2[2] - b2[0]) * (b2[3] - b2[1])
        union = a1 + a2 - inter
        return inter / union if union > 0 else 0.0

    def _distance(self, c1: Tuple, c2: Tuple) -> float:
        return ((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2) ** 0.5

    def _match_detections(
        self,
        detections: List[Tuple],   # List of (x1, y1, x2, y2, confidence)
        frame_num: int,
        timestamp: float,
    ) -> Tuple[Dict[str, Tuple], List[Tuple], List[str]]:
        """
        Returns:
            matched: {track_id: detection_bbox}
            unmatched_detections: [bbox, ...]  → new tracks
            lost_track_ids: [track_id, ...]    → tracks to expire
        """
        if not self.active_tracks or not detections:
            return {}, list(detections), list(self.active_tracks.keys()) if not detections else []

        track_ids = list(self.active_tracks.keys())
        track_bboxes = [self.active_tracks[tid].bbox for tid in track_ids]

        # Build cost matrix: combination of IoU and centroid distance
        cost = np.zeros((len(detections), len(track_ids)))
        for di, det in enumerate(detections):
            det_bbox = det[:4]
            det_c = self._centroid(det_bbox)
            for ti, tid in enumerate(track_ids):
                tr_bbox = track_bboxes[ti]
                tr_c = self._centroid(tr_bbox)
                iou_score = self._iou(det_bbox, tr_bbox)
                dist = self._distance(det_c, tr_c)
                # Composite score: high IoU = good match, low distance = good match
                if dist > MAX_TRACK_DISTANCE and iou_score < 0.1:
                    cost[di, ti] = 1e9  # Effectively impossible match
                else:
                    cost[di, ti] = dist * (1 - iou_score + 0.01)

        # Greedy matching (sufficient for this density of people in-store)
        matched = {}
        used_dets = set()
        used_tracks = set()

        while True:
            if cost.size == 0:
                break
            min_idx = np.unravel_index(np.argmin(cost), cost.shape)
            di, ti = min_idx
            if cost[di, ti] >= 1e8:
                break
            det_idx = di
            track_id = track_ids[ti]
            if det_idx not in used_dets and track_id not in used_tracks:
                matched[track_id] = detections[det_idx][:4]
                used_dets.add(det_idx)
                used_tracks.add(track_id)
            cost[di, :] = 1e9
            cost[:, ti] = 1e9

        unmatched_dets = [detections[i] for i in range(len(detections)) if i not in used_dets]
        lost_ids = [track_ids[i] for i in range(len(track_ids))
                    if track_ids[i] not in used_tracks]

        return matched, unmatched_dets, lost_ids

    def update(
        self,
        detections: List[Tuple],   # (x1, y1, x2, y2, confidence)
        frame_num: int,
        timestamp: float,
    ) -> Tuple[List[Track], List[Track], List[Track]]:
        """
        Process one frame's detections.

        Returns:
            new_confirmed: tracks confirmed this frame (emit ENTRY)
            updated: tracks still active
            expired: tracks that just died (emit EXIT)
        """
        matched, unmatched_dets, lost_ids = self._match_detections(
            detections, frame_num, timestamp
        )

        new_confirmed = []
        expired = []

        # Update matched tracks
        for track_id, bbox in matched.items():
            track = self.active_tracks[track_id]
            track.bbox = bbox
            track.centroid = self._centroid(bbox)
            track.last_seen_frame = frame_num
            track.last_seen_time = timestamp
            track.hit_count += 1
            track.age = 0
            if not track.confirmed and track.hit_count >= MIN_DETECTION_FRAMES:
                track.confirmed = True
                new_confirmed.append(track)

        # Age unmatched tracks
        for track_id in lost_ids:
            track = self.active_tracks[track_id]
            track.age += 1
            if track.age > MAX_TRACK_AGE:
                # Track expired → emit EXIT if confirmed
                expired.append(track)
                # Keep in lost_tracks for re-entry detection
                self.lost_tracks[track_id] = track
                del self.active_tracks[track_id]

        # Clean up old lost tracks (beyond re-entry window)
        stale = [tid for tid, t in self.lost_tracks.items()
                 if timestamp - t.last_seen_time > RE_ENTRY_WINDOW_SECONDS]
        for tid in stale:
            del self.lost_tracks[tid]

        # Create new tracks for unmatched detections
        for det in unmatched_dets:
            bbox = det[:4]
            centroid = self._centroid(bbox)

            # Check if this could be a re-entry (close to a recently lost track)
            re_entry_id = self._check_re_entry(centroid, timestamp)

            if re_entry_id:
                # Resurrect the lost track with same ID
                old = self.lost_tracks.pop(re_entry_id)
                old.bbox = bbox
                old.centroid = centroid
                old.last_seen_frame = frame_num
                old.last_seen_time = timestamp
                old.age = 0
                old.hit_count += 1
                self.active_tracks[re_entry_id] = old
                # Re-entries are flagged in metadata, not treated as new entries
            else:
                tid = self._new_track_id()
                track = Track(
                    track_id=tid,
                    camera_id=self.camera_id,
                    bbox=bbox,
                    centroid=centroid,
                    first_seen_frame=frame_num,
                    last_seen_frame=frame_num,
                    first_seen_time=timestamp,
                    last_seen_time=timestamp,
                )
                self.active_tracks[tid] = track

        return new_confirmed, list(self.active_tracks.values()), expired

    def _check_re_entry(self, centroid: Tuple, timestamp: float) -> Optional[str]:
        """Check if a new detection near a recently lost track = re-entry."""
        best_id = None
        best_dist = MAX_TRACK_DISTANCE * 2  # More lenient for re-entry
        for tid, track in self.lost_tracks.items():
            if timestamp - track.last_seen_time > RE_ENTRY_WINDOW_SECONDS:
                continue
            dist = self._distance(centroid, track.centroid)
            if dist < best_dist:
                best_dist = dist
                best_id = tid
        return best_id

    def get_current_occupancy(self) -> int:
        """Number of confirmed, active (non-staff) people currently tracked."""
        return sum(
            1 for t in self.active_tracks.values()
            if t.confirmed and not t.is_staff
        )
