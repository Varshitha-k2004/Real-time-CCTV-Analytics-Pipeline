"""
Event Schema for Store Intelligence System

All detection events are structured as typed dataclasses.
Events are the core primitive — everything else (metrics, funnel, anomalies)
is derived from events.

Design decision: Event-sourcing pattern — we store raw events and compute
metrics on read. This allows replaying history and changing business logic
without re-running the pipeline.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, Literal, List
from enum import Enum
import time
import json


class EventType(str, Enum):
    ENTRY = "entry"              # Person entered the store
    EXIT = "exit"                # Person exited the store
    DWELL = "dwell"              # Person dwelling in zone
    BILLING = "billing"          # Person at billing counter
    STAFF_DETECTED = "staff"     # Staff member identified
    RE_ENTRY = "re_entry"        # Person re-entered (counted as same visit)
    PEAK_ALERT = "peak_alert"    # Overcrowding / peak hour anomaly
    GROUP_ENTRY = "group_entry"  # Multiple people entering together


class Zone(str, Enum):
    ENTRANCE = "entrance"
    STORE_FLOOR = "store_floor"
    BILLING = "billing"
    STOCKROOM = "stockroom"


@dataclass
class BoundingBox:
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float

    def center(self):
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

    def area(self):
        return (self.x2 - self.x1) * (self.y2 - self.y1)


@dataclass
class DetectionEvent:
    """
    Core event unit produced by the detection pipeline.
    Every meaningful detection becomes one of these.
    """
    event_id: str
    event_type: EventType
    camera_id: str
    track_id: str                        # Unique track ID within a camera session
    global_person_id: Optional[str]      # Cross-camera resolved ID (None if not resolved)

    timestamp: float                     # Unix timestamp (seconds)
    frame_number: int
    zone: Zone

    # Optional spatial info
    bbox: Optional[BoundingBox] = None
    dwell_seconds: Optional[float] = None
    is_staff: bool = False
    group_size: Optional[int] = None     # For GROUP_ENTRY events

    # Anomaly fields
    store_occupancy: Optional[int] = None   # Snapshot of how many people in store
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["event_type"] = self.event_type.value
        d["zone"] = self.zone.value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "DetectionEvent":
        bbox = BoundingBox(**d["bbox"]) if d.get("bbox") else None
        return cls(
            event_id=d["event_id"],
            event_type=EventType(d["event_type"]),
            camera_id=d["camera_id"],
            track_id=d["track_id"],
            global_person_id=d.get("global_person_id"),
            timestamp=d["timestamp"],
            frame_number=d["frame_number"],
            zone=Zone(d["zone"]),
            bbox=bbox,
            dwell_seconds=d.get("dwell_seconds"),
            is_staff=d.get("is_staff", False),
            group_size=d.get("group_size"),
            store_occupancy=d.get("store_occupancy"),
            metadata=d.get("metadata", {}),
        )


@dataclass
class Session:
    """
    A visitor session: from entry to exit.
    Used for funnel analysis.
    """
    session_id: str
    global_person_id: str
    entry_time: float
    exit_time: Optional[float] = None
    reached_floor: bool = False
    reached_billing: bool = False
    purchased: bool = False          # Inferred: dwell at billing > threshold
    dwell_seconds: float = 0.0
    is_staff: bool = False
    re_entry_count: int = 0

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.exit_time:
            return self.exit_time - self.entry_time
        return None

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "global_person_id": self.global_person_id,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "reached_floor": self.reached_floor,
            "reached_billing": self.reached_billing,
            "purchased": self.purchased,
            "dwell_seconds": self.dwell_seconds,
            "is_staff": self.is_staff,
            "re_entry_count": self.re_entry_count,
            "duration_seconds": self.duration_seconds,
        }


class EventStore:
    """
    Simple append-only event store backed by JSON.

    Design decision: JSON file over SQLite for simplicity and portability.
    For production scale (millions of events/day), swap for TimescaleDB or
    ClickHouse. The interface is identical.
    """

    def __init__(self, path: str = "data/events.json"):
        self.path = path
        self._events: List[DetectionEvent] = []
        self._load()

    def _load(self):
        import os
        if os.path.exists(self.path):
            with open(self.path) as f:
                raw = json.load(f)
            self._events = [DetectionEvent.from_dict(e) for e in raw]

    def append(self, event: DetectionEvent):
        self._events.append(event)

    def save(self):
        import os
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            json.dump([e.to_dict() for e in self._events], f, indent=2)

    def all(self) -> List[DetectionEvent]:
        return list(self._events)

    def by_type(self, event_type: EventType) -> List[DetectionEvent]:
        return [e for e in self._events if e.event_type == event_type]

    def by_camera(self, camera_id: str) -> List[DetectionEvent]:
        return [e for e in self._events if e.camera_id == camera_id]

    def __len__(self):
        return len(self._events)
