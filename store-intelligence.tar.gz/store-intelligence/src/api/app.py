"""
Store Intelligence API

Endpoints:
  GET  /health              — liveness check
  GET  /metrics             — full store metrics snapshot
  GET  /funnel              — conversion funnel breakdown
  GET  /events              — raw event stream (filterable)
  GET  /anomalies           — detected anomalies
  GET  /occupancy/timeline  — occupancy over time
  POST /pipeline/run        — trigger pipeline re-processing
"""

import sys
import os
import time
import json
from typing import Optional, List

sys.path.insert(0, "/home/claude/store-intelligence")

from fastapi import FastAPI, HTTPException, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from src.events.schema import EventStore, EventType
from src.analytics.engine import AnalyticsEngine
from config.settings import EVENTS_DB_PATH, METRICS_CACHE_TTL

# ─── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Purplle Store Intelligence API",
    description="Real-time store analytics from CCTV footage — Brigade Road, Bangalore",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── State ──────────────────────────────────────────────────────────────────────
_event_store: Optional[EventStore] = None
_metrics_cache = None
_metrics_cache_time = 0.0
_pipeline_running = False


def get_store() -> EventStore:
    global _event_store
    if _event_store is None:
        _event_store = EventStore(EVENTS_DB_PATH)
    return _event_store


def get_analytics() -> AnalyticsEngine:
    return AnalyticsEngine(get_store())


def get_cached_metrics():
    global _metrics_cache, _metrics_cache_time
    now = time.time()
    if _metrics_cache is None or (now - _metrics_cache_time) > METRICS_CACHE_TTL:
        _metrics_cache = get_analytics().compute_metrics()
        _metrics_cache_time = now
    return _metrics_cache


# ─── Models ─────────────────────────────────────────────────────────────────────
class PipelineRunRequest(BaseModel):
    video_dir: str = "/mnt/user-data/uploads"
    max_frames: Optional[int] = None


# ─── Endpoints ──────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    store = get_store()
    return {
        "status": "ok",
        "events_loaded": len(store),
        "timestamp": time.time(),
        "pipeline_running": _pipeline_running,
    }


@app.get("/metrics")
def get_metrics():
    """
    Full store metrics snapshot.
    Includes footfall, funnel, dwell time, occupancy, and anomalies.
    Cached for 5 seconds.
    """
    metrics = get_cached_metrics()
    return JSONResponse(content=metrics.to_dict())


@app.get("/funnel")
def get_funnel():
    """
    Conversion funnel:
    Entered → Browsed → Billing → Purchased
    Includes drop-off at each stage and key insight.
    """
    analytics = get_analytics()
    return JSONResponse(content=analytics.compute_funnel())


@app.get("/events")
def get_events(
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    camera_id: Optional[str] = Query(None, description="Filter by camera"),
    limit: int = Query(100, le=1000),
    offset: int = Query(0),
):
    """
    Raw event stream. Supports filtering by type and camera.
    """
    store = get_store()
    events = store.all()

    if event_type:
        try:
            et = EventType(event_type)
            events = [e for e in events if e.event_type == et]
        except ValueError:
            raise HTTPException(400, f"Unknown event_type '{event_type}'. "
                                     f"Valid: {[e.value for e in EventType]}")

    if camera_id:
        events = [e for e in events if e.camera_id == camera_id]

    total = len(events)
    page = events[offset:offset + limit]

    return {
        "total": total,
        "offset": offset,
        "limit": limit,
        "events": [e.to_dict() for e in page],
    }


@app.get("/anomalies")
def get_anomalies():
    """
    All detected anomalies from the recording session.
    Includes overcrowding, low conversion, group entries, occupancy spikes.
    """
    metrics = get_cached_metrics()
    return {
        "count": len(metrics.anomalies),
        "anomalies": [
            {
                "anomaly_id": a.anomaly_id,
                "type": a.anomaly_type,
                "severity": a.severity,
                "description": a.description,
                "value": a.value,
                "threshold": a.threshold,
                "timestamp": a.timestamp,
            }
            for a in metrics.anomalies
        ],
    }


@app.get("/occupancy/timeline")
def get_occupancy_timeline(bucket_seconds: int = Query(30, ge=5, le=300)):
    """
    Occupancy over time, aggregated into time buckets.
    Use bucket_seconds to control granularity (default: 30s).
    """
    analytics = get_analytics()
    timeline = analytics.get_occupancy_timeline(bucket_seconds=bucket_seconds)
    return {
        "bucket_seconds": bucket_seconds,
        "total_buckets": len(timeline),
        "timeline": timeline,
    }


@app.get("/cameras")
def get_cameras():
    """Camera metadata and roles."""
    from config.settings import CAMERA_ROLES, AVAILABLE_CAMERAS
    store = get_store()
    events = store.all()

    camera_stats = {}
    for cam_id in AVAILABLE_CAMERAS:
        cam_events = [e for e in events if e.camera_id == cam_id]
        camera_stats[cam_id] = {
            "role": CAMERA_ROLES.get(cam_id, "unknown"),
            "event_count": len(cam_events),
            "available": True,
        }

    # CAM_1 was not provided
    camera_stats["CAM_1"] = {
        "role": "unknown",
        "event_count": 0,
        "available": False,
        "note": "Video file not present in dataset",
    }

    return camera_stats


@app.post("/pipeline/run")
async def run_pipeline(request: PipelineRunRequest, background_tasks: BackgroundTasks):
    """
    Trigger the detection pipeline on video files.
    Runs asynchronously. Poll /health to check status.
    """
    global _pipeline_running
    if _pipeline_running:
        raise HTTPException(409, "Pipeline already running")

    def _run():
        global _pipeline_running, _event_store, _metrics_cache
        _pipeline_running = True
        try:
            from src.pipeline.detector import Pipeline
            store = EventStore(EVENTS_DB_PATH)
            pipeline = Pipeline(request.video_dir, store)
            pipeline.run(max_frames_per_cam=request.max_frames)
            _event_store = store  # Refresh
            _metrics_cache = None  # Invalidate cache
        finally:
            _pipeline_running = False

    background_tasks.add_task(_run)
    return {"status": "started", "message": "Pipeline running in background. Poll /health for status."}


@app.get("/summary")
def get_summary():
    """Human-readable summary for quick assessment."""
    metrics = get_cached_metrics()
    f = metrics.funnel
    return {
        "store": "Purplle Brigade Road, Bangalore",
        "recording_date": metrics.recording_date,
        "duration_minutes": round(metrics.recording_duration_seconds / 60, 1),
        "highlights": {
            "total_visitors": metrics.total_entries,
            "unique_visitors": metrics.unique_visitors,
            "conversion_rate_pct": round(f.conversion_rate * 100, 1),
            "avg_dwell_minutes": round(metrics.dwell.avg_dwell_seconds / 60, 1),
            "peak_occupancy": metrics.peak_occupancy,
            "anomalies_detected": len(metrics.anomalies),
        },
        "funnel_summary": f"Of {f.total_entries} visitors: "
                          f"{f.engaged_visitors} browsed, "
                          f"{f.reached_billing} reached billing, "
                          f"{f.estimated_purchases} estimated purchases "
                          f"({f.conversion_rate:.1%} conversion).",
    }
