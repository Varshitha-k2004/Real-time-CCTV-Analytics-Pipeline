"""
Test Suite — Store Intelligence System

Tests cover:
- Event schema serialization/deserialization
- Tracker correctness (entry/exit detection, re-entry)
- Analytics computation (funnel, metrics, anomalies)
- API endpoint response validity
"""

import sys, os, time, uuid
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from src.events.schema import (
    DetectionEvent, EventType, Zone, BoundingBox, EventStore, Session
)
from src.pipeline.tracker import CentroidTracker, Track
from src.analytics.engine import AnalyticsEngine


# ─── Fixtures ───────────────────────────────────────────────────────────────────

def make_event(event_type=EventType.ENTRY, camera_id="CAM_3", track_id="T001",
               timestamp=None, is_staff=False, dwell_seconds=None, store_occupancy=3):
    return DetectionEvent(
        event_id=str(uuid.uuid4()),
        event_type=event_type,
        camera_id=camera_id,
        track_id=track_id,
        global_person_id=None,
        timestamp=timestamp or time.time(),
        frame_number=1,
        zone=Zone.ENTRANCE,
        bbox=BoundingBox(100, 100, 200, 400, 0.8),
        is_staff=is_staff,
        dwell_seconds=dwell_seconds,
        store_occupancy=store_occupancy,
    )


def make_store_with_session():
    """Returns an EventStore with a complete visitor session."""
    store = EventStore.__new__(EventStore)
    store._events = []
    t = 1744300800.0

    # Visitor enters
    store.append(make_event(EventType.ENTRY, track_id="T001", timestamp=t))
    # Visitor browses (dwell events from CAM_2)
    store.append(make_event(EventType.DWELL, camera_id="CAM_2", track_id="T001",
                            timestamp=t + 30, dwell_seconds=30))
    store.append(make_event(EventType.DWELL, camera_id="CAM_2", track_id="T001",
                            timestamp=t + 60, dwell_seconds=60))
    # Visitor at billing
    store.append(make_event(EventType.BILLING, camera_id="CAM_5", track_id="CAM_5_T001",
                            timestamp=t + 90, dwell_seconds=12))
    # Visitor exits
    store.append(make_event(EventType.EXIT, track_id="T001",
                            timestamp=t + 120, dwell_seconds=120))

    # Staff member
    store.append(make_event(EventType.STAFF_DETECTED, camera_id="CAM_4",
                            track_id="STAFF01", is_staff=True))
    return store


# ─── Event Schema Tests ──────────────────────────────────────────────────────────

class TestEventSchema:
    def test_event_serialization_roundtrip(self):
        ev = make_event(EventType.BILLING, dwell_seconds=15.5)
        d = ev.to_dict()
        restored = DetectionEvent.from_dict(d)
        assert restored.event_type == EventType.BILLING
        assert restored.dwell_seconds == 15.5
        assert restored.bbox is not None
        assert restored.bbox.x1 == 100

    def test_event_types_valid(self):
        for et in EventType:
            ev = make_event(et)
            assert ev.event_type == et
            d = ev.to_dict()
            assert d["event_type"] == et.value

    def test_bbox_center(self):
        bbox = BoundingBox(100, 100, 300, 500, 0.9)
        cx, cy = bbox.center()
        assert cx == 200
        assert cy == 300

    def test_event_store_append_and_filter(self):
        store = EventStore.__new__(EventStore)
        store._events = []
        store.append(make_event(EventType.ENTRY, track_id="T1"))
        store.append(make_event(EventType.EXIT, track_id="T1"))
        store.append(make_event(EventType.BILLING, track_id="T2"))
        assert len(store) == 3
        entries = store.by_type(EventType.ENTRY)
        assert len(entries) == 1
        cam3 = store.by_camera("CAM_3")
        assert len(cam3) >= 2


# ─── Tracker Tests ────────────────────────────────────────────────────────────────

class TestCentroidTracker:
    def test_new_detection_creates_track(self):
        tracker = CentroidTracker("TEST")
        dets = [(100, 100, 200, 400, 0.8)]
        _, active, _ = tracker.update(dets, 1, 1.0)
        assert len(active) == 1

    def test_track_confirmed_after_min_frames(self):
        from config.settings import MIN_DETECTION_FRAMES
        tracker = CentroidTracker("TEST")
        dets = [(100, 100, 200, 400, 0.8)]
        confirmed = []
        for i in range(MIN_DETECTION_FRAMES + 1):
            new_conf, active, _ = tracker.update(dets, i, float(i))
            confirmed.extend(new_conf)
        assert len(confirmed) >= 1
        assert confirmed[0].confirmed

    def test_track_expired_when_lost(self):
        from config.settings import MAX_TRACK_AGE, MIN_DETECTION_FRAMES
        tracker = CentroidTracker("TEST")
        dets = [(100, 100, 200, 400, 0.8)]
        # Confirm the track
        for i in range(MIN_DETECTION_FRAMES + 1):
            tracker.update(dets, i, float(i))
        # Send empty detections until track expires
        all_expired = []
        for i in range(MIN_DETECTION_FRAMES + 1, MIN_DETECTION_FRAMES + MAX_TRACK_AGE + 5):
            _, _, expired = tracker.update([], i, float(i))
            all_expired.extend(expired)
        assert len(all_expired) >= 1

    def test_iou_calculation(self):
        tracker = CentroidTracker("TEST")
        # Identical boxes → IoU = 1.0
        iou = tracker._iou((0, 0, 100, 100), (0, 0, 100, 100))
        assert abs(iou - 1.0) < 1e-5
        # No overlap → IoU = 0
        iou = tracker._iou((0, 0, 50, 50), (100, 100, 200, 200))
        assert iou == 0.0

    def test_two_separate_people_tracked_independently(self):
        tracker = CentroidTracker("TEST")
        # Two people far apart
        dets = [(0, 100, 100, 400, 0.8), (800, 100, 900, 400, 0.8)]
        _, active, _ = tracker.update(dets, 1, 1.0)
        assert len(active) == 2
        # Make sure they have different IDs
        ids = [t.track_id for t in active]
        assert ids[0] != ids[1]

    def test_occupancy_counts_only_confirmed(self):
        from config.settings import MIN_DETECTION_FRAMES
        tracker = CentroidTracker("TEST")
        dets = [(100, 100, 200, 400, 0.8)]
        # Before confirmation
        tracker.update(dets, 1, 1.0)
        assert tracker.get_current_occupancy() == 0
        # After confirmation
        for i in range(2, MIN_DETECTION_FRAMES + 2):
            tracker.update(dets, i, float(i))
        assert tracker.get_current_occupancy() == 1


# ─── Analytics Tests ──────────────────────────────────────────────────────────────

class TestAnalyticsEngine:
    def test_empty_store_returns_zero_metrics(self):
        store = EventStore.__new__(EventStore)
        store._events = []
        engine = AnalyticsEngine(store)
        m = engine.compute_metrics()
        assert m.total_entries == 0
        assert m.funnel.conversion_rate == 0.0
        assert m.total_events == 0

    def test_metrics_with_session(self):
        store = make_store_with_session()
        engine = AnalyticsEngine(store)
        m = engine.compute_metrics()
        assert m.total_entries >= 1
        assert m.total_exits >= 1
        assert m.staff_count >= 1
        assert m.dwell.avg_dwell_seconds > 0

    def test_funnel_stages_non_negative(self):
        store = make_store_with_session()
        engine = AnalyticsEngine(store)
        funnel = engine.compute_funnel()
        stages = funnel["stages"]
        assert len(stages) == 4
        for stage in stages:
            assert stage["count"] >= 0
            assert 0.0 <= stage["rate"] <= 10.0  # allow for cross-cam >1 temporarily

    def test_funnel_stage_order(self):
        store = make_store_with_session()
        engine = AnalyticsEngine(store)
        funnel = engine.compute_funnel()
        stages = funnel["stages"]
        assert stages[0]["stage"] == "Entered Store"
        assert stages[3]["stage"] == "Purchased"

    def test_anomaly_detection_overcrowding(self):
        store = EventStore.__new__(EventStore)
        store._events = []
        from config.settings import OVERCROWDING_THRESHOLD
        t = time.time()
        ev = make_event(EventType.PEAK_ALERT, timestamp=t,
                        store_occupancy=OVERCROWDING_THRESHOLD + 2)
        ev.metadata = {"occupancy": OVERCROWDING_THRESHOLD + 2}
        store.append(ev)
        engine = AnalyticsEngine(store)
        m = engine.compute_metrics()
        anomaly_types = [a.anomaly_type for a in m.anomalies]
        assert "overcrowding" in anomaly_types

    def test_occupancy_timeline_bucketing(self):
        store = make_store_with_session()
        t = 1744300800.0
        for i in range(10):
            ev = make_event(EventType.DWELL, timestamp=t + i * 5, store_occupancy=i % 4 + 1)
            store.append(ev)
        engine = AnalyticsEngine(store)
        timeline = engine.get_occupancy_timeline(bucket_seconds=15)
        assert isinstance(timeline, list)
        if timeline:
            assert "time_offset_seconds" in timeline[0]
            assert "avg_occupancy" in timeline[0]


# ─── API Integration Test ────────────────────────────────────────────────────────

class TestAPIEndpoints:
    """Quick smoke tests — ensure endpoints respond correctly."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient
        import sys
        sys.path.insert(0, "/home/claude/store-intelligence")
        # Override event store path
        import src.api.app as app_module
        app_module._event_store = make_store_with_session()
        from src.api.app import app
        return TestClient(app)

    def test_health_returns_ok(self, client):
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_metrics_returns_valid_structure(self, client):
        r = client.get("/metrics")
        assert r.status_code == 200
        data = r.json()
        assert "total_entries" in data
        assert "funnel" in data
        assert "dwell" in data
        assert "anomalies" in data

    def test_funnel_returns_four_stages(self, client):
        r = client.get("/funnel")
        assert r.status_code == 200
        data = r.json()
        assert "stages" in data
        assert len(data["stages"]) == 4

    def test_events_endpoint_pagination(self, client):
        r = client.get("/events?limit=2&offset=0")
        assert r.status_code == 200
        data = r.json()
        assert "total" in data
        assert len(data["events"]) <= 2

    def test_events_filter_by_type(self, client):
        r = client.get("/events?event_type=entry")
        assert r.status_code == 200
        events = r.json()["events"]
        for ev in events:
            assert ev["event_type"] == "entry"

    def test_invalid_event_type_returns_400(self, client):
        r = client.get("/events?event_type=INVALID_TYPE")
        assert r.status_code == 400

    def test_anomalies_endpoint(self, client):
        r = client.get("/anomalies")
        assert r.status_code == 200
        data = r.json()
        assert "count" in data
        assert "anomalies" in data

    def test_occupancy_timeline(self, client):
        r = client.get("/occupancy/timeline?bucket_seconds=30")
        assert r.status_code == 200
        data = r.json()
        assert "timeline" in data
        assert "bucket_seconds" in data

    def test_cameras_endpoint(self, client):
        r = client.get("/cameras")
        assert r.status_code == 200
        data = r.json()
        assert "CAM_3" in data
        assert "CAM_1" in data  # Missing cam still listed

    def test_summary_endpoint(self, client):
        r = client.get("/summary")
        assert r.status_code == 200
        data = r.json()
        assert "highlights" in data
        assert "funnel_summary" in data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
