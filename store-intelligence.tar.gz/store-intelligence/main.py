#!/usr/bin/env python3
"""
Store Intelligence System — Main Entry Point

Usage:
    # Run full pipeline on video files:
    python main.py --pipeline --video-dir /path/to/videos

    # Start API server only (uses existing events.json):
    python main.py --api

    # Run pipeline then start API:
    python main.py --pipeline --api --video-dir /path/to/videos

    # Run tests:
    python main.py --test
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def run_pipeline(video_dir: str, max_frames: int = None):
    """Run detection pipeline on all camera files."""
    from src.events.schema import EventStore
    from src.pipeline.detector import Pipeline

    os.makedirs("data", exist_ok=True)
    store = EventStore("data/events.json")

    print(f"\n{'='*60}")
    print("  Purplle Store Intelligence — Detection Pipeline")
    print(f"{'='*60}")
    print(f"  Video directory : {video_dir}")
    print(f"  Max frames/cam  : {max_frames or 'all'}")
    print(f"{'='*60}\n")

    pipeline = Pipeline(video_dir, store)
    total = pipeline.run(max_frames_per_cam=max_frames)

    print(f"\n{'='*60}")
    print(f"  Pipeline complete. {total} events emitted.")
    print(f"  Events saved to: data/events.json")
    print(f"{'='*60}\n")
    return store


def run_api(host: str = "0.0.0.0", port: int = 8000):
    """Start FastAPI server."""
    import uvicorn
    print(f"\n{'='*60}")
    print("  Purplle Store Intelligence — API Server")
    print(f"{'='*60}")
    print(f"  API docs : http://localhost:{port}/docs")
    print(f"  Metrics  : http://localhost:{port}/metrics")
    print(f"  Funnel   : http://localhost:{port}/funnel")
    print(f"  Health   : http://localhost:{port}/health")
    print(f"{'='*60}\n")
    uvicorn.run("src.api.app:app", host=host, port=port, reload=False)


def run_tests():
    """Run the test suite."""
    import subprocess
    result = subprocess.run(
        ["python3", "-m", "pytest", "tests/", "-v", "--tb=short"],
        cwd=os.path.dirname(os.path.abspath(__file__))
    )
    sys.exit(result.returncode)


def print_summary():
    """Print a quick metrics summary from existing events."""
    from src.events.schema import EventStore
    from src.analytics.engine import AnalyticsEngine
    import json

    if not os.path.exists("data/events.json"):
        print("No events found. Run --pipeline first.")
        return

    store = EventStore("data/events.json")
    engine = AnalyticsEngine(store)
    m = engine.compute_metrics()
    f = m.funnel

    print(f"\n{'='*60}")
    print("  Store Intelligence Summary")
    print(f"{'='*60}")
    print(f"  Recording date    : {m.recording_date}")
    print(f"  Duration          : {m.recording_duration_seconds:.0f}s")
    print(f"  Total events      : {m.total_events}")
    print()
    print(f"  FOOTFALL")
    print(f"    Entries         : {m.total_entries}")
    print(f"    Exits           : {m.total_exits}")
    print(f"    Unique visitors : {m.unique_visitors}")
    print(f"    Staff detected  : {m.staff_count}")
    print()
    print(f"  FUNNEL")
    print(f"    Entered         : {f.total_entries}")
    print(f"    Browsed         : {f.engaged_visitors}")
    print(f"    Reached billing : {f.reached_billing}")
    print(f"    Purchased       : {f.estimated_purchases}")
    print(f"    Conversion rate : {f.conversion_rate:.1%}")
    print()
    print(f"  DWELL TIME")
    print(f"    Average         : {m.dwell.avg_dwell_seconds:.1f}s")
    print(f"    Maximum         : {m.dwell.max_dwell_seconds:.1f}s")
    print()
    print(f"  OCCUPANCY")
    print(f"    Peak            : {m.peak_occupancy}")
    print(f"    Average         : {m.avg_occupancy:.1f}")
    print()
    print(f"  ANOMALIES ({len(m.anomalies)} detected)")
    for a in m.anomalies:
        print(f"    [{a.severity.upper():6s}] {a.anomaly_type}: {a.description[:60]}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Purplle Store Intelligence System")
    parser.add_argument("--pipeline", action="store_true", help="Run detection pipeline")
    parser.add_argument("--api", action="store_true", help="Start API server")
    parser.add_argument("--test", action="store_true", help="Run test suite")
    parser.add_argument("--summary", action="store_true", help="Print metrics summary")
    parser.add_argument("--video-dir", default="/mnt/user-data/uploads",
                        help="Directory containing CAM_*.mp4 files")
    parser.add_argument("--max-frames", type=int, default=None,
                        help="Max frames per camera (for testing; omit for full processing)")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)

    args = parser.parse_args()

    if args.test:
        run_tests()
    elif args.pipeline:
        run_pipeline(args.video_dir, args.max_frames)
        if args.api:
            run_api(args.host, args.port)
    elif args.api:
        run_api(args.host, args.port)
    elif args.summary:
        print_summary()
    else:
        print_summary()
        print("Run with --help for usage options.")
